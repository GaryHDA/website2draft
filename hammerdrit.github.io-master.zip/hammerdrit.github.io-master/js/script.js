
        $(function () {
            $('.go-down').click(function () {
                $('html,body').animate({scrollTop: 960}, 500);
            });
        });
    